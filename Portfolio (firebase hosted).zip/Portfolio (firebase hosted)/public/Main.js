// ******************** active class function for nav bar ******************** //

let section = document.querySelectorAll('section');
let navLink = document.querySelectorAll('a');

window.onscroll=()=>{
    section.forEach(sec=>{
        let top = window.scrollY;
        let offset = sec.offsetTop - 150;
        let height = sec.offsetHeight;
        let id = sec.getAttribute('id');
        if (top > offset && top <= offset + height){
            navLink.forEach(links => {
                document.querySelector('.nav-items a[href*='+ id +']').classList.add('active'); 
                links.classList.remove('active');                           
            });
        }
    });
}


// ******************** Dark mode function ******************** //

function myFunction() {
    var element = document.getElementById("sun-icon");
    var logo = document.getElementById("red-logo");
    var element1 = document.getElementById("sun-icon1");
    var logo1 = document.getElementById("red-logo1");
    
    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){
        element.src = " https://img.icons8.com/ios-glyphs/30/1A1A1A/moon-symbol.png " ;
        logo.src = " assets/lk-high-resolution-logo-transparent gold.png ";
        element1.src = " https://img.icons8.com/ios-glyphs/30/1A1A1A/moon-symbol.png " ;
        logo1.src = " assets/lk-high-resolution-logo-transparent gold.png ";
    }
    else{
        element.src = " https://img.icons8.com/ios-glyphs/30/FFFFFF/sun--v1.png ";
        logo.src = " assets/lk-high-resolution-logo-transparent.png ";
        element1.src = " https://img.icons8.com/ios-glyphs/30/FFFFFF/sun--v1.png ";
        logo1.src = " assets/lk-high-resolution-logo-transparent.png ";
    } 
} 


// ******************** project section selection function ******************** //

selection("all")
function selection(c) {
var x, i;
x = document.getElementsByClassName("card");
if (c == "all") c = "";
for (i = 0; i < x.length; i++) {
    RemoveCard(x[i], "show");
    if (x[i].className.indexOf(c) > -1) AddCard(x[i], "show");
}
}

// Show filtered elements
function AddCard(element, name) {
    var i, arr1, arr2;
    arr1 = element.className.split(" ");
    arr2 = name.split(" ");
    for (i = 0; i < arr2.length; i++) {
        if (arr1.indexOf(arr2[i]) == -1) {
            element.className += " " + arr2[i];
        }
    }
}

// Hide elements that are not selected
function RemoveCard(element, name) {
    var i, arr1, arr2;
    arr1 = element.className.split(" ");
    arr2 = name.split(" ");
    for (i = 0; i < arr2.length; i++) {
        while (arr1.indexOf(arr2[i]) > -1) {
            arr1.splice(arr1.indexOf(arr2[i]), 1);
        }
    }
    element.className = arr1.join(" ");
}

// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("btn-container");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active-link");
    current[0].className = current[0].className.replace(" active-link", "");
    this.className += " active-link";
    });
}


// ******************** form ******************** //

function validate(){

let name = document.getElementById("name").value;
let email = document.getElementById("email").value;
let phone = document.getElementById("phone").value;
let msg = document.getElementById("message").value;

if(name === "" ){
    Swal.fire({
        title: "Required!",
        text: "Name Field is required!!!",
        icon: "error"
    });
}else if(email === ""){
    Swal.fire({
        title: "Required!",
        text: "Email-Id Field is required!!!",
        icon: "error"
    });
}else if(phone === ""){
    Swal.fire({
        title: "Required!",
        text: "Phone Number Field is required!!!",
        icon: "error"
    });
}else if(msg === ""){
    Swal.fire({
        title: "Required!",
        text: "Message Field is required!!!",
        icon: "error"
    });
}else{
    Swal.fire({
        title: "Sent!",
        text: "Message Sent Successfully!!!",
        icon: "success"
    });
}
}


// ******************** Nav Bar ******************** //

const navMenu = document.getElementById('sidebar'),
      navToggle = document.getElementById('nav-toggle'),
      navClose = document.getElementById('nav-close');

if(navToggle){
    navToggle.addEventListener("click",()=>{
        navMenu.classList.add('show-sidebar')
    })
}
if(navClose){
    navClose.addEventListener("click",()=>{
        navMenu.classList.remove('show-sidebar')
    })
}